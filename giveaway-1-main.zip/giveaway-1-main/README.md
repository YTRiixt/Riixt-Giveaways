**This Giveaway bot was created by 𝐖𝐂 丶PĤÃŇtØM🥀
#2002**

**IN CONFIG.JSON DO NOT CHANGE ANY VARIABLE THE everyoneMention VARIABLE IS FOR THE EVERYONE MENTION WHEN A NEW GIVEAWAY OCCURS AND EVERYTHING ELSE IS SELF EPLAINATORY JUST CHANGE THE VALUES 
INSIDE "" TO MAKE YOUR BOT FUNCTION PROPERLY!**
# Links
- 🔗 [Youtube Channel](https://www.youtube.com/channel/UCtxWom0HSeOnGqXLTgGopMw)
- [Support Server Link](https://discord.gg/WOROP)
# Copyright 
Copyright 2021 © All RIghts are Reserved | If you are using any part of code please give me credits for the same. Thanks

# License
**ngnix 2021 all rights reserved**

**NOTE FOR GLITCH HOSTERS 
`` THIS BOT DIES IF YOU DON'T USE IT EVERY 5 MINUTES CAN BE EASILY RE-HOSTED BY REGENERATING THE TOKEN AND REPPLACING IT 
IF YOU WANT A SCRIPT THAT PREVENTS THIS JOIN THE SERVER ABOVE AND DM 0_0#6666 THIS MIGHT GET YOUR PROJECT SUSPENDED BUT YOU CAN ALWAYS
MAKE A NEW ONE USING MY TUTORIAL :D``**
``IF YOU DO NOT USE A COMMAND EVERY HALF AN HOUR ON REPL.IT HOSTING THE BOT DIES, CAN BE REVIVED BY RESTARTING IT``

# Host On Repl.it
[![Use on Repl.it](https://repl.it/badge/github/ZeroDiscord/GiveawayBot)](https://repl.it/github/ZeroDiscord/GiveawayBot)
